#ifndef IO_H
#define IO_H

void keyboard(unsigned char key, int x, int y);
void print_help();

#endif // IO_H
