#ifndef multiMatrix_H
#define multiMatrix_H

#include "definitions.h"

void aldaketaDesegin();

void biratu();
void tAldatu();
void mugitu();

void guztiaHanditu();
void guztiaTxikitu();
void pilaikusi();
#endif // multiMatrix_H
