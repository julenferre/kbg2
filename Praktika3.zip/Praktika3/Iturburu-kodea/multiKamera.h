#ifndef multiKamera_H
#define multiKamera_H

#include "definitions.h"

void kamera_mota_aldatu();

void orto_kam();
void obj_kam();
void ibil_kam();
#endif // multiKamera_H
