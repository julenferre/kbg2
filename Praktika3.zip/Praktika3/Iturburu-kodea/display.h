#ifndef DISPLAY_H
#define DISPLAY_H

#include "definitions.h"

void display(void);
void reshape(int width, int height);

void traslazioa();
void biraketa();
void tamainaAldaketa();

#endif // DISPLAY_H
