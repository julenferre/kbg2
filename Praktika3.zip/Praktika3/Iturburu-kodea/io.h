#ifndef IO_H
#define IO_H

void keyboard(unsigned char key, int x, int y);
void keyboardSpecial(int key, int x, int y);
void print_help();

void biratu();
void tAldatu();
void mugitu();
#endif // IO_H
